package cargarsintomas;

import cargarsintomas.controlador.Redactor;
import monitor.Sintoma;
import monitor.Sintomas;

import java.util.Set;

public class CargarSintomas {

    private Sintomas sintomas;
    private Redactor red;

    public CargarSintomas() {
     //   añadirNuevoSintoma();
        red = new Redactor();
        cargarSintomas();
    }
    public void imprimirSintomas(Sintomas sinto){
        for(Sintoma s : sinto){
            System.out.println("sintoma es: "+s);
        }
    }

    private void cargarSintomas() {
       sintomas =  red.leerSintoma();
       //imprimirSintomas(sintomas);
       // sintomas.imprimirSintomas();
    }
    public Sintomas getSintomas() {
        CargarSIU interfaz = new CargarSIU();
        sintomas =  red.leerSintoma();
        return sintomas;
    }
}
