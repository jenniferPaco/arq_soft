package cargarsintomas;
import cargarregistros.CargarRUI;
import cargarsintomas.controlador.Redactor;
import monitor.Sintoma;
import monitor.Sintomas;
import javax.swing.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class CargarSIU extends JFrame {
    private JButton cargarButton;
    private JTextField nombreSintoma;
    private JTextArea impresion;
    private JComboBox importancia;
    Redactor red = new Redactor();
    public CargarSIU(){
     super("Cargar Sintomas");
     importancia = new JComboBox();
     importancia.setBounds(0,300,150,50);
     impresion = new JTextArea();
    impresion.setForeground(Color.BLUE);
    impresion.setBounds(200,0,350,700);
    nombreSintoma = new JTextField();
    nombreSintoma.setBounds(0,50,180,40);
    cargarButton=new JButton("Cargar");
    cargarButton.setBounds(0,600,80,40);
    add(cargarButton);add(impresion); add(nombreSintoma); add(importancia);
    actualizarSintomas();
    dameCategos();
        final CargarSIU frameSintoma = this;
        this.addWindowListener(new WindowAdapter(){

            @Override
            public void windowClosing(WindowEvent we){
                try {
                    synchronized(frameSintoma){
                        frameSintoma.notify();
                    }
                    frameSintoma.setVisible(false);
                    frameSintoma.dispose();
                } catch (Exception e){
                    System.out.println(e.getMessage());
                    System.out.println("Error al guardar");
                }
            }
        });
        importancia.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        });
        cargarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cargar();
            }
        });
        nombreSintoma.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        });
    setSize(500,700);
    setLayout(null);
    setVisible(true);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        synchronized(frameSintoma){
            try{
                frameSintoma.wait();
            }
            catch(InterruptedException ex){
            }
        }
    }
    public void dameCategos(){
        String [] categos = red.getCategorias();
        for(int i=0; i<categos.length;i++){
            if(categos[i]!="f"){
                importancia.addItem(categos[i]);}
        }
    }
    public void actualizarSintomas(){
        Sintomas sintomas = red.leerSintoma();
        String res="--- Sintomas ---\n";
        for(Sintoma sin : sintomas){
            String arr= "Nombre: "+sin.toString() +"\n\tTipo: "+ sin.getClass();
            res=res+"\n"+arr;
        }
        impresion.setText(res);
    }
    public void cargar() {
        String clasificacion = importancia.getSelectedItem().toString();
        String nombre = nombreSintoma.getText();
        // int aux =selecciono(clasificacion);
        if(red.escribirFile(nombre,clasificacion)){
            JOptionPane.showMessageDialog(null,"Sintoma Agregado Correctamente");

        } else {
            JOptionPane.showMessageDialog(null,"Escriba bien el nombre de su sintoma");
        }
        actualizarSintomas();
    }


}
