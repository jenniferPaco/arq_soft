package cargarsintomas.controlador;

import monitor.Sintoma;
import monitor.Sintomas;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validador {

    public boolean validar(String n, Sintomas sintomas){
        n=n.toLowerCase();
        Pattern pat = Pattern.compile("^[a-z\s]{3,50}$");
        Matcher mat = pat.matcher(n);
        boolean cumpleSintaxis=mat.matches();
        boolean repetido=true;
        for(Sintoma s : sintomas){
            if(s.toString().equals(n)){
                repetido= false;

            }
            System.out.println(repetido);
        }
        return cumpleSintaxis&&repetido;
    }
}