package cargarsintomas.controlador;

import monitor.Sintoma;
import monitor.Sintomas;

import java.io.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Redactor {
    File archivo = null;
    String path = "cargarsintomas/sintomaso.txt";
   String pathCategorias = "sintomas";
  //String pathCategorias = "out/production/MonitorCovid/sintomas";
    FileReader fr = null;
    PrintWriter pw = null;
    BufferedReader br = null;
    FileInputStream fichero = null;
    FileOutputStream ficherito = null;
    Validador val = new Validador();
    public boolean escribirFile(String nombre,String categoria){
        archivo = new File(path);
        if(archivo.length() == 0){
            return escribirArchivo(nombre,categoria);
        }
        else{
          return   aniadirArchivo(nombre,categoria);
        }

    }
    public boolean aniadirArchivo(String nombre,String categoria){
        Sintoma sinto =null;
        nombre=nombre.toLowerCase();
        if (val.validar(nombre,leerSintoma())) {
            sinto =crearObjeto(nombre,"sintomas."+categoria);
            try{
                MiObjectOutputStream object = new MiObjectOutputStream(new FileOutputStream(path,true));
                object.writeObject(sinto);
                object.close();
            }catch(Exception e){
                e.printStackTrace();
            }
            return true;
        }
        else{
            return false;
        }
    }

    public boolean escribirArchivo(String nombre,String categoria) {
        Sintoma sinto =null;
        nombre=nombre.toLowerCase();
        if (val.validar(nombre,leerSintoma())) {
            sinto = crearObjeto(nombre, "sintomas." + categoria);
            try (ObjectOutputStream objectOutput = new ObjectOutputStream(
                    new FileOutputStream(path, true))) {
                objectOutput.writeObject(sinto);
                objectOutput.reset();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return true;
        }
            return false;
    }

    public Sintomas leerSintoma(){
        FileInputStream ficheroIn = null;
        Sintoma s=null;
        Sintomas sintomas= new Sintomas();
        try {
            ficheroIn = new FileInputStream(path);
            ObjectInputStream tuberiaEntrada = new ObjectInputStream(ficheroIn);
            s = (Sintoma)tuberiaEntrada.readObject();
            while(true){
                sintomas.add(s);
                s = (Sintoma)tuberiaEntrada.readObject();
            }
        } catch (IOException  e) {
            System.out.println("Lectura terminada");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return sintomas;
    }

    public String[] getCategorias(){
        File folder = new File(pathCategorias);
        String[] cats = folder.list();
        for(int i=0;i< cats.length;i++){
            cats[i]=cats[i].substring(0,cats[i].length()-6);
        }
        for(int e=0;e<cats.length;e++){
            if(!doyClase(cats[e],"sintomas."+cats[e])){
                cats[e]="f";
            }
        }
        return cats;
    }

    public Sintoma crearObjeto(String nonSintoma,String nombre){
        Sintoma s = null;
        Class<?> c;
        try {
            c = Class.forName(nombre);
            Constructor<?> cons = c.getConstructor(String.class);
            Object object = cons.newInstance(new Object[] { nonSintoma });
            s = (Sintoma) object;
        } catch (ClassNotFoundException classNotFoundException) {
            classNotFoundException.printStackTrace();
        } catch (NoSuchMethodException classNotFoundException) {
            System.out.println("Clase no instanciada Detectada");
            //classNotFoundException.printStackTrace();
        } catch (IllegalAccessException illegalAccessException) {
            illegalAccessException.printStackTrace();
        } catch (InstantiationException instantiationException) {
            instantiationException.printStackTrace();
        } catch (InvocationTargetException invocationTargetException) {
            invocationTargetException.printStackTrace();
        }
        return s;
    }
    public boolean doyClase(String n,String nombre) {
        return crearObjeto(n,nombre) instanceof Sintoma;
    }
    }

