import cargarregistros.CargarRegistros;
import cargarsintomas.CargarSIU;
import cargarsintomas.CargarSintomas;
import cargarsintomas.controlador.Redactor;
import monitor.Monitor;
import monitor.Sintoma;
import monitor.Sintomas;

public class Main {

    public static void main(String[] args){


        Monitor monitor = new Monitor();
        monitor.monitorear();
        System.out.println("resultado: " + monitor.getResultado());
    }

}
