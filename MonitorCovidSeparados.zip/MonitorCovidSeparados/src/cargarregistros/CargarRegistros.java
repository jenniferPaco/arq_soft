package cargarregistros;

import cargarsintomas.CargarSIU;
import cargarregistros.controlador.Redactor;
import monitor.Registro;
import monitor.Registros;
import monitor.Sintoma;
import monitor.Sintomas;


import java.util.Date;

public class CargarRegistros {

    private Registros registros;
    private Sintomas sintomas;
    private Redactor red;
    public CargarRegistros(Sintomas sintomas) {
        this.sintomas = sintomas;
        red = new Redactor();
        cargarRegistros();
        //añadirNuevoRegistro();
    }

    public void cargarRegistros(){
        registros = red.leerRegistro();
        if(registros!=null) {
           // registros.imprimirRegistros();
        }else{
            registros=new Registros();
        }
    }

    public Registro getRegistro() {
        for (Sintoma s: sintomas) {
            System.out.println(s);
        }
        CargarRUI inter = new CargarRUI(sintomas);
        Registro r = inter.getUltimo();
        return r;
    }
    public Registros getRegistros(){
        return registros;
    }
}
