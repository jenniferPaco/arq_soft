package cargarregistros.controlador;

import monitor.Registro;
import monitor.Registros;
import monitor.Sintoma;
import monitor.Sintomas;

import java.io.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Date;

public class Redactor {
    File archivo = null;
    //String path = "registros.txt";
    String path ="cargarregistros/registrados.txt";
    FileReader fr = null;
    PrintWriter pw = null;
    BufferedReader br = null;
    FileInputStream fichero = null;
    FileOutputStream ficherito = null;


    public boolean escribirArchivo1() {
        Registros registros = new Registros();
        try (ObjectOutputStream objectOutput = new ObjectOutputStream(
                new FileOutputStream(path))) {
            objectOutput.writeObject(registros);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }


    public boolean escribirArchivo(Registro r) {
        Registros registros = leerRegistro();
       // Registro r = new Registro(fecha, sintomas);
        if(registros!=null){
            registros.push(r);
        }else{
            registros= new Registros();
            registros.push(r);
        }
        try (ObjectOutputStream objectOutput = new ObjectOutputStream(
                new FileOutputStream(path))) {
            objectOutput.writeObject(registros);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }

    public Registros leerRegistro() {
        FileInputStream ficheroIn = null;
        Registros registros = null;
        try {
            ficheroIn = new FileInputStream(path);
            ObjectInputStream tuberiaEntrada = new ObjectInputStream(ficheroIn);
            registros = (Registros) tuberiaEntrada.readObject();
        } catch (IOException e) {
            System.out.println("Lectura terminada REGISTROS");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        if(registros==null){
            registros = new Registros();
        }
        return registros;
    }
}


